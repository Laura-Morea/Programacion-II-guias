package cafetera;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class ModuloAgua {

    private double temperatura;
    private boolean requiereMantenimiento;
    public static final double TEMP_MIN = 70.0;

    public void calentarAgua() {
        // Método a resolver...
    }

}