package cafetera;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public enum TipoCafe {

    EXPRESSO,
    LATTE,
    LAGRIMA;
    private int cantLeche;

    private TipoCafe(int int1) {
        // Constructor a resolver...
    }

    public int getCantLeche() {
        // Método a resolver...
        return 0;
    }

}