package cafetera;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class MaquinaDeCafe {

    private String marca;
    private boolean encendida;
    private ModuloLeche moduloLeche;
    private ModuloAgua moduloAgua;

    public void encender() {
        // Método a resolver...
    }

    public void servirCafe(TipoCafe tipocafe1) {
        // Método a resolver...
    }

    public void recargarLeche(int int1) {
        // Método a resolver...
    }

    public void calentarAgua() {
        // Método a resolver...
    }

}