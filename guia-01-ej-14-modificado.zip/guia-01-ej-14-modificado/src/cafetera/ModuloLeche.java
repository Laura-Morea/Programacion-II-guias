package cafetera;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class ModuloLeche {

    private Object liquido;
    public static final int MIN_CANT_LECHE = 0;
    public static final int MAX_CANT_LECHE = 5;
    private TexturaLeche textura;

    public void recargarLeche(int int1) {
        // Método a resolver...
    }

}